package com.poc.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.poc.dao.JobDao;
import com.poc.model.Job;
import com.poc.response.SuccessResponse;
import com.poc.utility.ExcelHelper;

@Service
public class JobServiceImpl implements JobService {

	@Autowired
	private JobDao jobDao;
	Logger logger = Logger.getLogger(this.getClass());

	SuccessResponse response = new SuccessResponse();

	@Override
	public SuccessResponse createJob(Job job) {
		logger.debug("incoming request for createJob JobServiceImpl :: " + job);
		try {
			Job save = jobDao.save(job);
			logger.debug("response for createJob JobServiceImpl ::" + save);
			if (save != null) {
				List<Job> list = new ArrayList<>();
				list.add(save);
				response.setJob(list);
				response.setStatusCode("200");
				response.setStatusMessage("job created successfully");
				return response;
			} else {
				logger.debug("job not created");
				response.setStatusCode("422");
				response.setStatusMessage("job not created");
				return response;
			}

		} catch (Exception e) {
			logger.error("error message in createJob JobServiceImpl" + e.getMessage());
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobById(int id) {
		logger.debug("incoming request for getJobById JobServiceImpl :: " + id);
		List<Job> job = new ArrayList<Job>();
		try {
			Job findJobById = jobDao.findJobById(id);
			logger.debug("response for getJobById JobServiceImpl ::" + findJobById);
			if (findJobById != null) {
				job.add(findJobById);
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobById JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByType(String type) {
		logger.debug("incoming request for getJobByType JobServiceImpl :: " + type);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByType = jobDao.findJobByType(type);
			logger.debug("response for getJobByType JobServiceImpl ::" + findJobByType);
			if (findJobByType != null && !findJobByType.isEmpty()) {
				response.setJob(findJobByType);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobByType JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByExperience(int exp) {
		logger.debug("incoming request for getJobByExperience JobServiceImpl :: " + exp);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByExperience = jobDao.findJobByExperience(exp);
			logger.debug("response for getJobByExperience JobServiceImpl ::" + findJobByExperience);
			if (findJobByExperience != null && !findJobByExperience.isEmpty()) {
				response.setJob(findJobByExperience);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobByExperience JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByCountry(String country) {
		logger.debug("incoming request for getJobByCountry JobServiceImpl :: " + country);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByCountry = jobDao.findJobByCountry(country);
			logger.debug("response for getJobByCountry JobServiceImpl ::" + findJobByCountry);
			if (findJobByCountry != null && !findJobByCountry.isEmpty()) {
				response.setJob(findJobByCountry);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobByCountry JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByAvailability(String availability) {
		logger.debug("incoming request for getJobByAvailability JobServiceImpl :: " + availability);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByAvailability = jobDao.findJobByAvailability(availability);
			logger.debug("response for getJobByAvailability JobServiceImpl ::" + findJobByAvailability);
			if (findJobByAvailability != null && !findJobByAvailability.isEmpty()) {
				response.setJob(findJobByAvailability);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobByAvailability JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}

	}

	@Override
	public SuccessResponse getJobBySkills(String skills) {
		logger.debug("incoming request for getJobBySkills JobServiceImpl :: " + skills);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobBySkills = jobDao.findJobBySkills(skills);
			logger.debug("response for getJobBySkills JobServiceImpl ::" + findJobBySkills);
			if (findJobBySkills != null && !findJobBySkills.isEmpty()) {
				response.setJob(findJobBySkills);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobBySkills JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByLanguage(String language) {
		logger.debug("incoming request for getJobByLanguage JobServiceImpl :: " + language);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByLanguage = jobDao.findJobByLanguage(language);
			logger.debug("response for getJobByLanguage JobServiceImpl ::" + findJobByLanguage);
			if (findJobByLanguage != null && !findJobByLanguage.isEmpty()) {
				response.setJob(findJobByLanguage);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobBySkills JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getJobByPayRate(int payRateLow, int payRateHigh) {
		logger.debug("incoming request for getJobByPayRate JobServiceImpl :: " + payRateLow + " " + payRateHigh);
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findJobByPayRate = jobDao.findJobByPayRate(payRateLow, payRateHigh);
			logger.debug("response for getJobByPayRate JobServiceImpl ::" + findJobByPayRate);
			if (findJobByPayRate != null && !findJobByPayRate.isEmpty()) {
				response.setJob(findJobByPayRate);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getJobByPayRate JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	@Override
	public SuccessResponse getAllJobs() {
		List<Job> job = new ArrayList<Job>();
		try {
			List<Job> findAll = jobDao.findAll();
			logger.debug("response for getAllJobs JobServiceImpl ::" + findAll);
			if (findAll != null && !findAll.isEmpty()) {
				response.setJob(findAll);
				response.setStatusCode("200");
				response.setStatusMessage("records fetched successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(job);
				response.setStatusCode("200");
				response.setStatusMessage("no records found");
				return response;
			}
		} catch (Exception e) {
			logger.error("error message in getAllJobs JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;
		}
	}

	public SuccessResponse save(MultipartFile file) {
		logger.debug("incoming request for save JobServiceImpl :: " + file);
		List<Job> jobsList = new ArrayList<>();
		try {
			List<Job> jobs = ExcelHelper.excelToTutorials(file.getInputStream());
			List<Job> saveAll = jobDao.saveAll(jobs);
			logger.debug("response for save JobServiceImpl ::" + saveAll);
			if (saveAll != null && !saveAll.isEmpty()) {
				response.setJob(saveAll);
				response.setStatusCode("200");
				response.setStatusMessage("data uploaded successfully");
				return response;
			} else {
				logger.debug("no records found");
				response.setJob(jobsList);
				response.setStatusCode("200");
				response.setStatusMessage("data not uploaded");
				return response;
			}
		} catch (IOException e) {
			logger.error("error message in save JobServiceImpl" + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(e.getMessage());
			return response;

		}
	}

}