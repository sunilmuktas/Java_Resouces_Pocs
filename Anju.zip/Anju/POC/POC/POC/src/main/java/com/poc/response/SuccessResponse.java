package com.poc.response;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.poc.model.Job;
import com.poc.model.User;

@XmlRootElement
public class SuccessResponse {
	private User user;
	private List<Job> job;
	private String statusMessage;
	private String statusCode;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Job> getJob() {
		return job;
	}

	public void setJob(List<Job> job) {
		this.job = job;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
