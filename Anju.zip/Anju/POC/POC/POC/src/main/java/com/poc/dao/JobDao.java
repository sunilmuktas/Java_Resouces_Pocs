package com.poc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.poc.model.Job;

public interface JobDao extends JpaRepository<Job, Long> {

	Job findJobById(int id);

	@Query(value = "select * from job where job_type = ?1", nativeQuery = true)
	List<Job> findJobByType(String type);

	List<Job> findJobByExperience(int exp);

	List<Job> findJobByCountry(String country);

	List<Job> findJobByAvailability(String availability);

	@Query(value = "select * from job where skills like %?1%", nativeQuery = true)
	List<Job> findJobBySkills(String skills);

	List<Job> findJobByLanguage(String language);

	@Query(value = "SELECT * FROM job WHERE pay_rate BETWEEN ?1 AND ?2", nativeQuery = true)
	List<Job> findJobByPayRate(int payRateLow, int payRateHigh);

}
