package com.poc.service;

import org.springframework.web.multipart.MultipartFile;

import com.poc.model.Job;
import com.poc.response.SuccessResponse;

public interface JobService {

	SuccessResponse save(MultipartFile file);

	SuccessResponse createJob(Job job);

	SuccessResponse getJobById(int id);

	SuccessResponse getJobByType(String type);

	SuccessResponse getJobByExperience(int exp);

	SuccessResponse getJobByCountry(String country);

	SuccessResponse getJobByAvailability(String availability);

	SuccessResponse getJobBySkills(String skills);

	SuccessResponse getJobByLanguage(String language);

	SuccessResponse getJobByPayRate(int payRateLow, int payRateHigh);

	SuccessResponse getAllJobs();

}
