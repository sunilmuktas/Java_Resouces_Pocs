package com.poc.controller;

import org.apache.log4j.Logger;
import org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.poc.model.Job;
import com.poc.response.ErrorResponse;
import com.poc.response.SuccessResponse;
import com.poc.service.JobService;
import com.poc.utility.ExcelHelper;

@RestController
@RequestMapping("/job")
public class JobController {

	@Autowired
	private JobService service;
	Logger logger = Logger.getLogger(this.getClass());
	ErrorResponse response = new ErrorResponse();

	@PostMapping(value = "/postjob", produces = { "application/json", "application/xml" }, consumes = {
			"application/json", "application/xml" })
	public ResponseEntity<Object> createJob(@RequestBody Job job) {
		logger.debug("incoming request for JobController :: " + job);
		if (job.getJobTitle() != null && !job.getJobTitle().isEmpty() && job.getJobDescription() != null
				&& !job.getJobDescription().isEmpty() && job.getCountry() != null && !job.getCountry().isEmpty()
				&& job.getState() != null && !job.getState().isEmpty() && job.getAvailability() != null
				&& !job.getAvailability().isEmpty() && job.getReplyRate() >= 0 && job.getPayRate() >= 0
				&& job.getExperience() >= 0 && job.getSkills() != null && !job.getSkills().isEmpty()
				&& job.getLanguage() != null && !job.getLanguage().isEmpty() && job.getJobType() != null
				&& job.getUserInfo().getUserName() != null && !job.getUserInfo().getUserName().isEmpty()) {
			SuccessResponse createJob = service.createJob(job);
			logger.debug("response for createUser JobController ::" + createJob);
			return new ResponseEntity<Object>(createJob, HttpStatus.OK);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping(value = "/getJob/{id}")
	public ResponseEntity<Object> getJobById(@PathVariable("id") int id) {
		logger.debug("incoming request for getJobById JobController :: " + id);
		if (id >= 0) {
			SuccessResponse jobById = service.getJobById(id);
			logger.debug("response for getJobById JobController ::" + jobById);
			return new ResponseEntity<Object>(jobById, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}

	}

	@GetMapping(value = "getByType/{type}")
	public ResponseEntity<Object> getJobByType(@PathVariable("type") String type) {
		logger.debug("incoming request for getJobByType JobController :: " + type);

		if (type != null) {
			SuccessResponse jobByType = service.getJobByType(type);
			logger.debug("response for getJobByType JobController ::" + jobByType);
			return new ResponseEntity<Object>(jobByType, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping("/getByExp/{exp}")
	public ResponseEntity<Object> getJobByExperience(@PathVariable("exp") int exp) {
		logger.debug("incoming request for getJobByExperience JobController :: " + exp);
		if (exp >= 0) {
			SuccessResponse jobByExperience = service.getJobByExperience(exp);
			logger.debug("response for getJobByExperience JobController :: " + jobByExperience);
			return new ResponseEntity<Object>(jobByExperience, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping("/getByCountry/{country}")
	public ResponseEntity<Object> getJobByCountry(@PathVariable("country") String country) {
		logger.debug("incoming request for getJobByCountry JobController :: " + country);
		if (country != null) {
			SuccessResponse jobByCountry = service.getJobByCountry(country);
			logger.debug("response for getJobByCountry JobController :: " + jobByCountry);
			return new ResponseEntity<Object>(jobByCountry, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}

	}

	@GetMapping("/getByAvailability/{availability}")
	public ResponseEntity<Object> getJobByAvailability(@PathVariable("availability") String availability) {
		logger.debug("incoming request for getJobByAvailability JobController :: " + availability);

		if (availability != null) {
			SuccessResponse jobByAvailability = service.getJobByAvailability(availability);
			logger.debug("response for getJobByAvailability JobController :: " + jobByAvailability);
			return new ResponseEntity<Object>(jobByAvailability, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping("/getBySkills/{skills}")
	public ResponseEntity<Object> getJobBySkills(@PathVariable("skills") String skills) {
		logger.debug("incoming request for getJobBySkills JobController :: " + skills);

		if (skills != null) {
			SuccessResponse jobBySkills = service.getJobBySkills(skills);
			logger.debug("response for getJobBySkills JobController :: " + jobBySkills);
			return new ResponseEntity<Object>(jobBySkills, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping("/getByLanguage/{language}")
	public ResponseEntity<Object> getJobByLanguage(@PathVariable("language") String language) {
		logger.debug("incoming request for getJobByLanguage JobController :: " + language);

		if (language != null) {
			SuccessResponse jobByLanguage = service.getJobByLanguage(language);
			logger.debug("response for getJobByLanguage JobController :: " + jobByLanguage);
			return new ResponseEntity<Object>(jobByLanguage, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping("/getByPayRate/{low}/{high}")
	public ResponseEntity<Object> getJobByPayRate(@PathVariable("low") int payRateLow,
			@PathVariable("high") int payRateHigh) {
		logger.debug("incoming request for getJobByPayRate JobController :: " + payRateLow + " " + payRateHigh);
		if (payRateLow >= 0 && payRateHigh >= 0) {
			SuccessResponse jobByPayRate = service.getJobByPayRate(payRateLow, payRateHigh);
			logger.debug("response for getJobByPayRate JobController :: " + jobByPayRate);
			return new ResponseEntity<Object>(jobByPayRate, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@GetMapping(value = "/getalljobs", produces = { "application/json", "application/xml" }, consumes = {
			"application/json", "application/xml" })
	public ResponseEntity<Object> getAllJobs() {
		SuccessResponse allJobs = service.getAllJobs();
		logger.debug("response for getAllJobs JobController :: " + allJobs);
		if (allJobs != null) {
			return new ResponseEntity<Object>(allJobs, HttpStatus.OK);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@PostMapping("/upload")
	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) throws DuplicateName {
		String message = "";
		if (ExcelHelper.hasExcelFormat(file)) {
			try {
				SuccessResponse save = service.save(file);
				logger.debug("response for uploadFile JobController :: " + save);
				return new ResponseEntity<Object>(save, HttpStatus.OK);
			} catch (Exception e) {
				logger.error(e.getMessage());
				response.setStatusCode("422");
				response.setStatusMessage(e.getMessage());
				return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
			}
		}

		message = "Please upload an excel file!";
		return new ResponseEntity<Object>(message, HttpStatus.UNPROCESSABLE_ENTITY);
	}
}
