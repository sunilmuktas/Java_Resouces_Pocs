package com.poc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.model.User;
import com.poc.response.ErrorResponse;
import com.poc.response.SuccessResponse;
import com.poc.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService service;

	Logger logger = Logger.getLogger(this.getClass());

	@PostMapping(value = "/createUser", produces = { "application/json", "application/xml" }, consumes = {
			"application/json", "application/xml" })
	public ResponseEntity<Object> createUser(@RequestBody User user) {
		logger.debug("incoming request for createUser JobController ::" + user);
		ErrorResponse response = new ErrorResponse();
		if (user.getUserName() != null && !user.getUserName().isEmpty()) {
			SuccessResponse saveUser = service.createUser(user);
			logger.debug("response for createUser JobController ::" + saveUser);
			return new ResponseEntity<Object>(saveUser, HttpStatus.ACCEPTED);
		} else {
			logger.debug("request is invalid");
			response.setStatusMessage("request is invalid");
			response.setStatusCode("422");
			return new ResponseEntity<Object>(response, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}
}