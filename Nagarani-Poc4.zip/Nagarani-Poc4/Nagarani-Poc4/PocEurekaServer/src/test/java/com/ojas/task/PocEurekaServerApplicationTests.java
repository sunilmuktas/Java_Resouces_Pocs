package com.ojas.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
