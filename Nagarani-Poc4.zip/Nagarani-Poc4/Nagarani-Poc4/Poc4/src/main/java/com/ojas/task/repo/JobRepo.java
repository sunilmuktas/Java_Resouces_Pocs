package com.ojas.task.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ojas.task.entity.Job;

public interface JobRepo extends JpaRepository<Job, Integer>{

	public Optional<Job> findById(Integer id);
	
	public List<Job> findByJobType(String type);
	
	public List<Job> findByExperience(Integer exp);
	
	public List<Job> findByCountry(String country);
	
	public List<Job> findByAvailabilityIn(List<String> availability);
	
	public List<Job> findBySkillsContains(String skills);
	
	public List<Job> findByLanguage(String lang);
	
	public List<Job> findByPayRateBetween(Integer low,Integer high);
}
