package com.ojas.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
