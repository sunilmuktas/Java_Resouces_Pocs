package com.ojas.ecom.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.ecom.customexception.CustomizedException;
import com.ojas.ecom.model.User;
import com.ojas.ecom.repository.UserRepository;
import com.ojas.ecom.response.UserResponse;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	Logger logger = Logger.getLogger(this.getClass());

	@Override
	public UserResponse saveUser(User user) {
		UserResponse response = null;
		logger.debug("data coming into the service class");
		try {

			if (user.getUserName() == null && user.getUserName().trim().length() == 0)
				throw new CustomizedException("field is missing");

			User saveUser = userRepo.save(user);
			response = new UserResponse();
			response.setUserList(saveUser);
			response.setStatusCode("200");
			response.setMessage("User record saved successfully");
		} catch (CustomizedException e) {
			response = new UserResponse();
			response.setMessage(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			response = new UserResponse();
			response.setMessage(e.getLocalizedMessage());
			response.setStatusCode(e.getLocalizedMessage());
		}
		return response;

	}
}