package com.ojas.ecom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ojas.ecom.model.Job;
import com.ojas.ecom.response.JobResponse;

@Service
public interface JobService {
	       
	ResponseEntity<Object> saveJob(Job job);
	 public List<Job>findJobs(Job job);
	 public ResponseEntity<Object> getById(Integer id);
	 public ResponseEntity<Object>getByJobType(String type);
	 ResponseEntity<Object>findByExperience(Integer experience);
	 public ResponseEntity<Object>findByCountry(String country);
	 public ResponseEntity<Object> findByAvailability(String availability);
	 public ResponseEntity<Object>findBySkills(String skills);
	 public ResponseEntity<Object>findByLanguage(String language);
	 public List<Job> findByPayRateBetween(Integer low,Integer high);
	
}
