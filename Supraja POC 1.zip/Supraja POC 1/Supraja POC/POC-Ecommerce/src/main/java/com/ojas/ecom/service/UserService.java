package com.ojas.ecom.service;

import org.springframework.stereotype.Service;

import com.ojas.ecom.model.User;
import com.ojas.ecom.response.UserResponse;


@Service
public interface UserService {
	public UserResponse saveUser(User user);
}
