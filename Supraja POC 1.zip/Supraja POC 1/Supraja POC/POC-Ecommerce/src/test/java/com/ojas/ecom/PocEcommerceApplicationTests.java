package com.ojas.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
