package com.poc.service;

import com.poc.model.User;
import com.poc.response.SuccessResponse;

public interface UserService {

	SuccessResponse createUser(User user);

}
