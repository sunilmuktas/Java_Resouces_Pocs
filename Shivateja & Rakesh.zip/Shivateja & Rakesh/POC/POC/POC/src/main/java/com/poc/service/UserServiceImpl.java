package com.poc.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.dao.UserDao;
import com.poc.model.User;
import com.poc.response.SuccessResponse;
import com.poc.utility.DuplicateException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;
	Logger logger = Logger.getLogger(this.getClass());

	@Override
	public SuccessResponse createUser(User user) {
		logger.debug("incoming request for createUser UserServiceImpl :: " + user);
		SuccessResponse response = new SuccessResponse();
		try {
			User save = dao.save(user);
			logger.debug("response for createUser UserServiceImpl :: " + save);
			if (save != null) {
				response.setUser(user);
				response.setStatusCode("200");
				response.setStatusMessage("user created successfully");
				return response;
			} else {
				response.setStatusCode("422");
				response.setStatusMessage("user not created");
				return response;
			}
		} catch (Exception e) {
			DuplicateException dupException = new DuplicateException("Duplicates are not allowed");
			logger.error("response for createUser UserServiceImpl :: " + e.getMessage());
			response.setStatusCode("422");
			response.setStatusMessage(dupException.getMessage());
			return response;
		}
	}
}