package com.emp.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.emp.model.ExcelHelper;
import com.emp.model.Job;
import com.emp.repository.JobRepository;

@Service
public class JobSevice implements JobServiceInterface {
	@Autowired
	private JobRepository jobRepository;

	@Override
	public Job save(Job job) {
		Job save = jobRepository.save(job);
		return save;
	}

	@Override
	public List<Job> findJobByJobId(Integer jobId) {
		return jobRepository.findJobByJobId(jobId);
	}

	@Override
	public List<Job> findJobByJobType(String jobType) {
		return jobRepository.findJobByJobType(jobType);

	}

	@Override
	public List<Job> findJobByExperience(Float experience) {
		return jobRepository.findJobByExperience(experience);

	}

	@Override
	public List<Job> findJobByCountry(String country) {
		return jobRepository.findJobByCountry(country);
	}

	@Override
	public List<Job> findByAvailabilityIn(String availability) {
		String[] string = availability.split(",");
		List<String> list = Arrays.asList(string);
		return jobRepository.findByAvailabilityIn(list);
	}

	@Override
	public List<Job> findBySkills(String skills) {
		return jobRepository.findBySkills(skills);
	}

	@Override
	public List<Job> findJobByLanguage(String language) {
		return jobRepository.findJobByLanguage(language);
	}

	@Override
	public List<Job> findJobByPayRate(Integer low, Integer high) {
		return jobRepository.findJobByPayRateBetween(low, high);
	}

	@Override
	public List<Job> findAllJob() {
		return jobRepository.findAll();
	}

	public List<Job> saveAll(MultipartFile file) {
		try {
			List<Job> jobs = ExcelHelper.excelToTutorials(file.getInputStream());
			List<Job> saveAll = jobRepository.saveAll(jobs);
			System.out.println(saveAll);
			return saveAll;
		} catch (IOException e) {
			System.out.println("from exception");
			throw new RuntimeException("fail to store excel data: " + e.getMessage());
		}
	}
}
