package com.emp.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.emp.model.ExcelHelper;
import com.emp.model.Job;
import com.emp.service.JobServiceInterface;

@RestController
public class JobController {
	private final Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private JobServiceInterface jobService;

	@PostMapping(value = "/postJob", produces = { "application/json", "application/xml" }, consumes = {
			"application/json", "application/xml" })
	public ResponseEntity<Job> save(@Valid @RequestBody Job job) {
		Job save = jobService.save(job);
		logger.info("inside save method of job");
		if (save != null) {
			return new ResponseEntity<>(save, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@GetMapping(value = "/getJobByJobId/{jobId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<Object> findJobByJobId(@PathVariable Integer jobId) {
		logger.info("inside findJobByJobId method of job");
		List<Job> findJobByJobId = jobService.findJobByJobId(jobId);
		if (findJobByJobId != null) {
			return new ResponseEntity<>(findJobByJobId, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getJobByType/{jobType}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findJobByJobType(@PathVariable String jobType) {
		logger.info("inside findJobByJobType method of job");
		List<Job> findJobByJobType = jobService.findJobByJobType(jobType);
		if (findJobByJobType != null) {
			return new ResponseEntity<>(findJobByJobType, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getJobByExp/{experience}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findJobByExperience(@PathVariable Float experience) {
		logger.info("inside findJobByExperience method of job");
		List<Job> findJobByExperience = jobService.findJobByExperience(experience);
		if (findJobByExperience != null) {
			return new ResponseEntity<>(findJobByExperience, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getJobByCountry/{country}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findJobByCountry(@PathVariable String country) {
		logger.info("inside findJobByCountry method of job");
		List<Job> findJobByCountry = jobService.findJobByCountry(country);
		if (findJobByCountry != null) {
			return new ResponseEntity<>(findJobByCountry, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getByAvailability/{availability}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findByAvailability(@PathVariable String availability) {
		logger.info("inside findByAvailability method of job");
		List<Job> findByAvailability = jobService.findByAvailabilityIn(availability);
		if (findByAvailability != null) {
			return new ResponseEntity<>(findByAvailability, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getBySkills/{skills}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findBySkills(@PathVariable String skills) {
		logger.info("inside findBySkills method of job");
		List<Job> findBySkills = jobService.findBySkills(skills);
		if (findBySkills != null) {
			return new ResponseEntity<>(findBySkills, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getJobByLanguage/{language}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findJobByLanguage(@PathVariable String language) {
		logger.info("inside findJobByLanguage method of job");
		List<Job> findJobByLanguage = jobService.findJobByLanguage(language);
		if (findJobByLanguage != null) {
			return new ResponseEntity<>(findJobByLanguage, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getJobByPayRate/{low}/{high}", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findJobByPayRateBetween(@PathVariable Integer low, @PathVariable Integer high) {
		logger.info("inside findJobByPayRateBetween method of job");
		List<Job> findJobByPayRate = jobService.findJobByPayRate(low, high);
		if (findJobByPayRate != null) {
			return new ResponseEntity<>(findJobByPayRate, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/getAllJobs", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Job>> findAllJob() {
		logger.info("inside findAllJob method of job");
		List<Job> findAllJob = jobService.findAllJob();
		if (findAllJob != null) {
			return new ResponseEntity<>(findAllJob, HttpStatus.OK);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@PostMapping("/processJobExcel")
	public List<Job> uploadFile(@RequestParam("file") MultipartFile file) {

		logger.info("inside uploadFile method of job");

		if (ExcelHelper.hasExcelFormat(file)) {

			try {
				List<Job> list = jobService.saveAll(file);
				return list;

			} catch (Exception e) {
				System.out.println(e.getMessage());
				return new ArrayList<Job>();

			}
		} else {
			System.out.println("not excel format");
			return new ArrayList<>();
		}

	}

}
