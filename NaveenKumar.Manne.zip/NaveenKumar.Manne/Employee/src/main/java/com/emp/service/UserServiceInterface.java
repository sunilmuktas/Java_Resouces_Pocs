package com.emp.service;

import com.emp.model.User;

public interface UserServiceInterface {
public User save(User user);
}
