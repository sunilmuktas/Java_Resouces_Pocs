package com.emp.service;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

import com.emp.model.Job;

public interface JobServiceInterface {
public Job save(Job job);
public List<Job> findJobByJobId(Integer jobId);
public List<Job> findJobByJobType(String jobType);
public List<Job> findJobByExperience(Float experience);
public List<Job> findJobByCountry(String country);

public List<Job> findByAvailabilityIn(String availability);
public List<Job> findBySkills(String skills);
public List<Job> findJobByLanguage(String language);
public List<Job> findJobByPayRate(Integer low, Integer high);
public List<Job> findAllJob();
public List<Job> saveAll(MultipartFile file);

}
