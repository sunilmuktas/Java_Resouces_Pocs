package com.example.demo.util;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.example.demo.entity.Job;

public class Response {
	private Object result;
	private String message;
	private HttpStatus status;
	private String expMessage;

	public Response getRes(List<Job> list, Response response) {

		if (list.size() == 0) {
			response.setMessage("No users found");
			response.setStatus(HttpStatus.NO_CONTENT);
		} else {
			response.setMessage("users found");
			response.setResult(list);
			response.setStatus(HttpStatus.FOUND);
		}
		return response;
	}

	public String getExpMessage() {
		return expMessage;
	}

	public void setExpMessage(String expMessage) {
		this.expMessage = expMessage;
	}

	@Override
	public String toString() {
		return "Response [result=" + result + ", message=" + message + ", status=" + status + "]";
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

}
