package com.example.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.entity.Job;
import com.example.demo.repo.IUserRepository;
import com.example.demo.repo.JobRepo;
import com.example.demo.util.ExcelHelper;
import com.example.demo.util.Response;

@Service
public class JobService {
	@Autowired
	private JobRepo repo;
	@Autowired
	private IUserRepository userRepo;

	public Response saveJob(Job job) {
		Response response = new Response();
		Job save = null;
		try {

			save = repo.save(job);
			response.setMessage("User saved with username" + save.getUserName());
			response.setResult(save);
			response.setStatus(HttpStatus.CREATED);
			return response;

		} catch (Exception e) {
			response.setMessage("user not saved");
			response.setStatus(HttpStatus.BAD_REQUEST);
			response.setExpMessage(e.getMessage());
			return response;
		}

	}

	public Response getJobById(Integer id) {

		Response response = new Response();
		try {
			Optional<Job> findById = repo.findById(id);
			response.setMessage("user found");
			response.setResult(findById);
			response.setStatus(HttpStatus.FOUND);
			return response;
		} catch (Exception e) {
			response.setMessage("Object Not Found");
			response.setStatus(HttpStatus.NOT_FOUND);
			response.setExpMessage(e.getMessage());
			return response;
		}

	}

	public Response findJobByJobType(String jobType) {
		Response response = new Response();

		try {
			List<Job> list = repo.findJobByJobType(jobType);
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.NOT_FOUND);
			return response;
		}
	}

	public Response findJobByExperience(int exp) {
		Response response = new Response();

		try {
			List<Job> list = repo.findJobByExperience(exp);
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			return response;

		}

	}

	public Response findJobByCountry(String country) {
		Response response = new Response();
		try {
			List<Job> list = repo.findJobByCountry(country);
			return response.getRes(list, response);
		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			return response;

		}

	}

	public Response findByAvailability(List<String> availability) {
		Response response = new Response();

		try {
			List<Job> list = repo.findByAvailabilityIn(availability);
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			return response;
		}

	}

	public Response findAll() {
		Response response = new Response();

		try {
			List<Job> list = repo.findAll();
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			return response;
		}
	}

	public Response findBySkillsContaining(String skill) {
		Response response = new Response();

		try {
			List<Job> list = repo.findBySkillsContaining(skill);
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setExpMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			return response;
		}
	}

	public Response saveAll(MultipartFile file) {
		Response response = new Response();

		try {
			List<Job> jobs = ExcelHelper.excelToDb(file.getInputStream());
			if (jobs != null) {
				List<Job> saveAll = repo.saveAll(jobs);
				response.setResult(saveAll);
			} else {
				throw new IOException();
			}
		} catch (IOException e) {
			response.setMessage(e.getMessage());
		}
		return response;
	}

	public Response findByPayRateBetween(Integer low, Integer high) {
		Response response = new Response();

		try {
			List<Job> list = repo.findByPayRateBetween(low, high);
			return response.getRes(list, response);

		} catch (Exception e) {
			response.setMessage(e.getMessage());
			return response;
		}
	}

}
